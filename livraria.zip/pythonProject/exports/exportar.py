from pathlib import Path
import csv
import sqlite3

def exportar_para_csv():
    conexao = sqlite3.connect('meu_banco.db')
    cursor = conexao.cursor()

    cursor.execute('SELECT * FROM livro')
    livros = cursor.fetchall()

    caminho_export = Path(__file__).resolve().parent.parent / 'exports'
    caminho_csv = caminho_export / 'livros_exportados.csv'

    caminho_export.mkdir(parents=True, exist_ok=True)

    with open(caminho_csv, 'w', newline='', encoding='utf-8') as csvfile:
        escritor = csv.writer(csvfile)
        escritor.writerow(['ID', 'Titulo', 'Autor', 'Ano de Publicação', 'Preço'])

        for livro in livros:
            escritor.writerow(livro)

    print(f'Dados exportados com sucesso para {caminho_csv}')

    if caminho_csv.exists():
        print(f"O arquivo {caminho_csv} foi criado com sucesso.")
    else:
        print(f"Erro: O arquivo {caminho_csv} não foi criado.")

    conexao.close()