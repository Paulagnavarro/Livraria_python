from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from pathlib import Path
import sqlite3


def gerar_relatorio_pdf():
    conexao = sqlite3.connect('meu_banco.db')
    cursor = conexao.cursor()

    caminho_pdf = Path(__file__).resolve().parent.parent / 'exports' / 'relatorio_livros.pdf'

    cursor.execute('SELECT * FROM livro')
    livros = cursor.fetchall()

    c = canvas.Canvas(str(caminho_pdf), pagesize=letter)
    c.setFont("Helvetica", 12)

    c.drawString(220, 750, "Relatório de Livros")

    c.drawString(50, 700, "ID")
    c.drawString(100, 700, "Título")
    c.drawString(300, 700, "Autor")
    c.drawString(400, 700, "Ano de Publicação")
    c.drawString(500, 700, "Preço")

    y = 680
    for livro in livros:
        try:
            preco = float(livro[4])
            c.drawString(50, y, str(livro[0]))
            c.drawString(100, y, livro[1])
            c.drawString(300, y, livro[2])
            c.drawString(400, y, str(livro[3]))
            c.drawString(500, y, f"R$ {preco:.2f}")
        except ValueError:
            c.drawString(500, y, "Preço inválido")

        y -= 20

    c.save()
    print(f'Relatório PDF criado com sucesso: {caminho_pdf}')

    conexao.close()
