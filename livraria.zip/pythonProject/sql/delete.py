import sqlite3
from backup.backups import fazer_backup

conexao = sqlite3.connect('meu_banco.db')
cursor = conexao.cursor()

def remover_livro():
    fazer_backup()
    titulo = input("Digite o título do livro que deseja remover: ")

    if not titulo.strip():
        print("Título inválido! O título não pode ser vazio.")
        return

    cursor.execute('''DELETE FROM livro WHERE titulo = ?''', (titulo,))

    conexao.commit()

    if cursor.rowcount > 0:
        print("Livro removido com sucesso!")
    else:
        print("Livro não encontrado!")
