import sqlite3

conexao = sqlite3.connect('meu_banco.db')
cursor = conexao.cursor()

def exibir_todos_livros():
    conexao = sqlite3.connect('meu_banco.db')
    cursor = conexao.cursor()

    cursor.execute('SELECT * FROM livro')
    resultado = cursor.fetchall()

    for linha in resultado:
        print(f"Titulo: {linha[1]}, Autor: {linha[2]}, Ano lançamento: {linha[3]}, Preço: {linha[4]}")

    print('-' * 30)

    conexao.close()

if __name__ == "__main__":
    exibir_todos_livros()
