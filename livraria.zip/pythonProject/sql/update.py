import sqlite3
from backup.backups import fazer_backup

conexao = sqlite3.connect('meu_banco.db')
cursor = conexao.cursor()


def atualizar_preco():
    fazer_backup()
    titulo = input("Digite o título do livro que deseja atualizar: ")

    while True:
        novo_preco = input("Digite o novo preço do livro (use . ao invés de ,): ")
        try:
            novo_preco_float = float(novo_preco)
            if novo_preco_float >= 0:
                break
            else:
                print("Preço inválido! O preço deve ser um número positivo.")
        except ValueError:
            print("Entrada inválida! Por favor, insira um valor numérico para o preço.")

    cursor.execute('''UPDATE livro SET preco = ? WHERE titulo = ?''', (novo_preco_float, titulo))

    conexao.commit()

    if cursor.rowcount > 0:
        print("Preço atualizado com sucesso!")
    else:
        print("Livro não encontrado!")