from insert import inserir_livro
from livro_select import exibir_todos_livros
from buscaLivro import buscar_livros_por_autor
from update import atualizar_preco
from delete import remover_livro
from exports.exportar import exportar_para_csv
from imports.import_csv import importar_de_csv
from backup.backups import fazer_backup
from exports.relatorio import gerar_relatorio_pdf


def main():
    while True:
        print("\nMenu:")
        print("1. Adicionar novo livro")
        print("2. Exibir todos os livros")
        print("3. Atualizar preço de um livro")
        print("4. Remover um livro")
        print("5. Buscar livros por autor")
        print("6. Exportar dados para CSV")
        print("7. Importar dados de CSV")
        print("8. Fazer backup do banco de dados")
        print("9. Exportar dados para PDF")
        print("10. Sair")

        escolha = input("Digite o número da opção desejada: ")

        if escolha == '1':
            inserir_livro()
        elif escolha == '2':
            exibir_todos_livros()
        elif escolha == '3':
            atualizar_preco()
        elif escolha == '4':
            remover_livro()
        elif escolha == '5':
            buscar_livros_por_autor()
        elif escolha == '6':
            exportar_para_csv()
        elif escolha == '7':
            importar_de_csv()
        elif escolha == '8':
            fazer_backup()
        elif escolha == '9':
            gerar_relatorio_pdf()
        elif escolha == '10':
            print("Saindo...")
            break
        else:
            print("Opção inválida, tente novamente.")


if __name__ == "__main__":
    main()
