import sqlite3

conexao = sqlite3.connect('meu_banco.db')
cursor = conexao.cursor()

def buscar_livros_por_autor():
    autor = input("Digite o nome do autor que deseja buscar: ")

    cursor.execute('SELECT * FROM livro WHERE autor = ?', (autor,))
    resultado = cursor.fetchall()

    if resultado:
        print(f'Livros do autor {autor}:')
        for linha in resultado:
            print(f"ID: {linha[0]}, Titulo: {linha[1]}, Autor: {linha[2]}, Ano de publicação: {linha[3]}, Preço: {linha[4]}")
    else:
        print(f"Nenhum livro encontrado para o autor '{autor}'.")