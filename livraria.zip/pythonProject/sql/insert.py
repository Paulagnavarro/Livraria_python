import sqlite3
from backup.backups import fazer_backup

conexao = sqlite3.connect('meu_banco.db')
cursor = conexao.cursor()

def inserir_livro():
    fazer_backup()

    titulo = input("Digite o título do livro: ")
    autor = input("Digite o autor do livro: ")

    while True:
        ano_publicacao = input("Digite o ano de publicação: ")
        if ano_publicacao.isdigit() and 1000 <= int(ano_publicacao) <= 2100:
            break
        else:
            print("Ano inválido! Por favor, insira um ano entre 1000 e 2100.")

    while True:
        preco = input("Digite o preço do livro (use . ao invés de ,): ")
        try:
            preco_float = float(preco)
            if preco_float >= 0:
                break
            else:
                print("Preço inválido! O preço deve ser um número positivo.")
        except ValueError:
            print("Entrada inválida! Por favor, insira um valor numérico para o preço.")

    cursor.execute('''INSERT INTO livro (titulo, autor, ano_publicacao, preco) VALUES (?, ?, ?, ?)''',
                   (titulo, autor, ano_publicacao, preco_float))

    conexao.commit()
    print("Livro inserido com sucesso!")