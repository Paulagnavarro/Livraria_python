import sqlite3

conexao = sqlite3.connect('meu_banco.db')

cursor = conexao.cursor()

print("Conexão estabelecida com sucesso!")
