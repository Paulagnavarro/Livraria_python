from pathlib import Path
import shutil
from datetime import datetime
from backup.limpar_backups import limpar_backups

def fazer_backup():
    caminho_banco = Path(r'C:\Users\Paula\Documents\python\livraria\pythonProject\sql\meu_banco.db')

    data_atual = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')

    caminho_backup = Path(f'C:/Users/Paula/Documents/python/livraria/pythonProject/backup/backup_livraria_{data_atual}.db')

    if not caminho_banco.exists():
        print(f"Erro: O arquivo {caminho_banco} não foi encontrado.")
        return

    if not caminho_backup.parent.exists():
        caminho_backup.parent.mkdir(parents=True, exist_ok=True)
        print(f"Pasta de backup criada: {caminho_backup.parent}")

    shutil.copy(caminho_banco, caminho_backup)
    print(f"Backup criado com sucesso: {caminho_backup}")

    limpar_backups()

fazer_backup()