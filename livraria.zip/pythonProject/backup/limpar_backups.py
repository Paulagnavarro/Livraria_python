from pathlib import Path
import os

def limpar_backups():
    caminho_backups = Path('C:/Users/Paula/Documents/python/livraria/pythonProject/backup/')

    arquivos_backup = list(caminho_backups.glob('backup_livraria_*.db'))

    arquivos_backup.sort(key=os.path.getmtime, reverse=True)

    arquivos_para_remover = arquivos_backup[5:]

    for arquivo in arquivos_para_remover:
        try:
            arquivo.unlink()
            print(f"Arquivo removido: {arquivo.name}")
        except Exception as e:
            print(f"Erro ao remover {arquivo.name}: {e}")

if __name__ == "__main__":
    limpar_backups()