import sqlite3
import csv
from pathlib import Path

def importar_de_csv():
    conexao = sqlite3.connect('meu_banco.db')
    cursor = conexao.cursor()

    caminho_csv = Path(__file__).resolve().parent.parent / 'exports' / 'livros_exportados.csv'

    if not caminho_csv.exists():
        print(f"Erro: O arquivo {caminho_csv} não foi encontrado.")
        conexao.close()
        return

    with open(caminho_csv, 'r', encoding='utf-8') as csvfile:
        leitor = csv.reader(csvfile)
        next(leitor)

        for linha in leitor:
            preco = float(linha[4].replace(',', '.'))
            cursor.execute('''
                INSERT INTO livro (titulo, autor, ano_publicacao, preco) 
                VALUES (?, ?, ?, ?)
            ''', (linha[1], linha[2], int(linha[3]), preco))

    conexao.commit()
    print(f'Dados importados com sucesso de {caminho_csv}')
    conexao.close()
